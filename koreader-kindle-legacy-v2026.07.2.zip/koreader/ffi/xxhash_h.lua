-- Automatically generated with ffi-cdecl.

require("ffi").cdef[[
typedef struct XXH3_state_s XXH3_state_t;
typedef uint64_t XXH64_hash_t;
typedef enum {
  XXH_OK = 0,
  XXH_ERROR,
} XXH_errorcode;
XXH3_state_t *XXH3_createState(void);
XXH_errorcode XXH3_freeState(XXH3_state_t *);
XXH_errorcode XXH3_64bits_reset(XXH3_state_t *);
XXH_errorcode XXH3_64bits_update(XXH3_state_t *, const void *, size_t);
XXH64_hash_t XXH3_64bits_digest(const XXH3_state_t *);
]]
