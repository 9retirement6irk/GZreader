# Credits

`plank-oak.png` is the oak plank of
[Bookshelf](https://github.com/AndyHazz/bookshelf.koplugin) by AndyHazz
(version 6.4.2, `assets/planks/oak/plank.middle.png`), in greys, the top's
rows above the front's, at 480 x 32. Bookshelf is under the AGPL-3.0, the
licence GZreader and KOReader are under too (`COPYING` at the top of this
repository).

## Photorealistic ornaments (`ornament-photo-*.png`)

Renders of objects from [Poly Haven](https://polyhaven.com) (its own preview
pictures of its 3D models), in greys with transparency. Poly Haven's assets
are CC0: free for any purpose, no credit required (https://polyhaven.com/license).
Credit is given gladly; the file names keep Poly Haven's:

| File | Poly Haven model | Authors |
|---|---|---|
| `potted-plant-01` | potted_plant_01 | Rico Cilliers |
| `potted-plant-02` | potted_plant_02 | Rico Cilliers |
| `potted-plant-04` | potted_plant_04 | James Ray Cock |
| `concrete-cat-statue` | concrete_cat_statue | Rico Cilliers, Riley Queen |
| `marble-bust-01` | marble_bust_01 | Rico Cilliers |
| `horse-statue-01` | horse_statue_01 | Rico Cilliers |
| `lantern-01` | Lantern_01 | Rajil Jose Macatangay |
| `alarm-clock-01` | alarm_clock_01 | Yann Kervran, James Ray Cock |
| `mantel-clock-01` | mantel_clock_01 | Yann Kervran, Rico Cilliers |
| `antique-ceramic-vase-01` | antique_ceramic_vase_01 | James Ray Cock |
| `brass-vase-01` | brass_vase_01 | Rico Cilliers |
| `wooden-candlestick` | wooden_candlestick | Josh Dean |
| `dutch-ship-medium` | dutch_ship_medium | James Ray Cock, Rico Cilliers, Nicolò Zubbini |
| `vintage-binocular` | vintage_binocular | Luke |
| `lambis-shell` | lambis_shell | Kuutti Siitonen |
| `jug-01` | jug_01 | Kuutti Siitonen |

## Pictures supplied by the owner

`ornament-photo-christmas-tree.png`, `ornament-photo-pumpkin.png` and
`ornament-photo-tabby-cat.png` were supplied by the owner of this repository
(2026-11-11) and cut out and turned to greys for GZreader. Where they come
from and their licences are **not recorded here**: add the source and
licence of each, or replace the picture, before relying on them being free
to redistribute.

The other pictures here are GZreader's own.
